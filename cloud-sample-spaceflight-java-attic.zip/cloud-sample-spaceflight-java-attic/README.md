This is the content of the former 'space travel' application. 

For updated content see the [README file in the master branch](https://github.com/SAP/cloud-sample-spaceflight-java).
